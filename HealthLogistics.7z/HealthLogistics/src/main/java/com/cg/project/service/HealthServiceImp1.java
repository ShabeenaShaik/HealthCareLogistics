package com.cg.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.cg.project.bean.Logistics;
import com.cg.project.bean.Registration;
import com.cg.project.dao.HealthDao;

@Service
public class HealthServiceImp1 implements HealthService{

	@Autowired
	HealthDao healthDao;
	
	//This is for creating a registration page
	@Override
	public Integer createRegistration(Registration registration) {
		// TODO Auto-generated method stub
		return healthDao.createRegistration(registration);
	}
	
	////This is for adding tests 
	@Override
	public Integer addTests(Logistics logistics) {
		// TODO Auto-generated method stub
		return healthDao.addTests(logistics);
	}
	
	//This is to get all user details from the database
	@Override
	public List<Registration> getUserDetails() {
		// TODO Auto-generated method stub
		return healthDao.getUserDetails();
	}
	
	//This is for login validation
	@Override
	public Integer validateByMailPswd(String mailId, String pswd) {
		// TODO Auto-generated method stub
		return healthDao.validateByMailPswd(mailId,pswd);
	}
	
	//This is to get all the technician details from database
	@Override
	public List<Registration> getTechnicianDetails() {
		// TODO Auto-generated method stub
		return healthDao.getTechnicianDetails();
	}
	
	//This is for booking the technician
	@Override
	public Integer booking(String usermail, String tecnicianMail) {
		// TODO Auto-generated method stub
		return healthDao.booking(usermail, tecnicianMail);
	}
	
	////This is to get the details of users who booked that technician
	@Override
	public List<Registration> getDetails(String technicianMail) {
		// TODO Auto-generated method stub
		return healthDao.getDetails(technicianMail);
	}
	
	//This is to view all the tests that are added
	@Override
	public List<Logistics> viewTests() {
		// TODO Auto-generated method stub
		return healthDao.viewTests();
	}
	
	//This is to add all equipement details like equipement name and equipement price
	@Override
	public Integer addEquipment(String name, Integer price) {
		// TODO Auto-generated method stub
		return healthDao.addEquipment(name,price);
	}
	
	//This is to view all the equipement that are added
	@Override
	public List<Logistics> getEquipment() {
		// TODO Auto-generated method stub
		return healthDao.getEquipment();
	}
	
	//This is to save the changes that are made in equipement price and equipement name
	@Override
	public Integer saveChanges(String ename, Integer eprice) {
		// TODO Auto-generated method stub
		return healthDao.saveChanges(ename,eprice);
	}
	
	//This is to delete the equipement details
	@Override
	public void deleteEquipment(String ename) {
		// TODO Auto-generated method stub
		healthDao.delete(ename);
		
	}
	
	//This is to save changes that are made to test name and test price
	@Override
	public Integer saveTestChanges(String tname, Integer tprice) {
		// TODO Auto-generated method stub
		return healthDao.saveTestChanges(tname,tprice);
	}
	
	//This is to delete the tests 
	@Override
	public void deleteTests(String tname) {
		// TODO Auto-generated method stub
		healthDao.deleteTests(tname);
		
	}
	

}
