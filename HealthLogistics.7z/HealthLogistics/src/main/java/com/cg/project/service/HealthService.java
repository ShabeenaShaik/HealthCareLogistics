package com.cg.project.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.cg.project.bean.Logistics;
import com.cg.project.bean.Registration;
 

//This is a interface for healthService
public interface HealthService {

	public Integer createRegistration(Registration registration);
	public Integer addTests(Logistics logistics);
	public List<Registration> getUserDetails();
	public Integer validateByMailPswd(String mailId, String pswd);
	public List<Registration> getTechnicianDetails();
	public Integer booking(String usermail, String tecnicianMail);
	public List<Registration> getDetails(String technicianMail);
	public List<Logistics> viewTests();
	public Integer addEquipment(String name, Integer price);
	public List<Logistics>getEquipment();
	public Integer saveChanges(String ename, Integer eprice);
	public void deleteEquipment(String ename);
	public Integer saveTestChanges(String tname, Integer tprice);
	public void deleteTests(String tname);
}
