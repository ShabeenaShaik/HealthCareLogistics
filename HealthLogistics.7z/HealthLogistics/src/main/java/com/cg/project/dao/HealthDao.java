package com.cg.project.dao;

import java.io.IOException;
import java.util.List;

import com.cg.project.bean.Logistics;
import com.cg.project.bean.Registration;

//This is a interface for healthDao

public interface HealthDao {

	public Integer createRegistration(Registration registration);
	public Integer addTests(Logistics logistics);
	public List<Registration> getUserDetails();
	public Integer validateByMailPswd(String mailId, String pswd);
	public List<Registration> getTechnicianDetails();
	public Integer booking(String usermail, String tecnicianMail);
	public List<Registration> getDetails(String technicianMail);
	public List<Logistics> viewTests();
	public Integer addEquipment(String name, Integer price);
	public List<Logistics>getEquipment();
	public Integer saveChanges(String ename, Integer eprice);
	public void delete(String ename);
	public Integer saveTestChanges(String tname, Integer tprice);
	public void deleteTests(String tname);
	
}
