import { Component, OnInit } from '@angular/core';
import { ManagerService } from './manager.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-delete-test',
  templateUrl: './delete-test.component.html',
  styleUrls: ['./delete-test.component.css']
})
export class DeleteTestComponent implements OnInit {
test:any={};
  constructor(private managerService:ManagerService,private router:Router) { }

  ngOnInit() {
    this.managerService.viewTests().subscribe((data:any)=>{this.test=data});
  }
  save(tName,tPrice){
    this.managerService.tName=tName;
    this.managerService.tPrice=tPrice; 
    this.router.navigate(['./editTest']);
    
  }
  deleteTests(tName:any,tPrice:any){
    return this.managerService.deleteTest(tName).subscribe((data:any)=>{
      if(data==1){
        alert("deleted successfully");
        this.router.navigate(['./viewTests']);
      }
    })
    
  }

  logout(){
    this.router.navigate(['./home']);
  }
  add2(){
    this.router.navigate(["./addTests"]);
  }
  add1(){
    this.router.navigate(["./addEquipment"]);
  }
  view1(){
    this.router.navigate(['./viewEquipment']);
  }

}
