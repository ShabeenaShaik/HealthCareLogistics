import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ManagerService } from './manager.service';

@Component({
  selector: 'app-custaddeuipement',
  templateUrl: './custaddeuipement.component.html',
  styleUrls: ['./custaddeuipement.component.css']
})
export class CustaddeuipementComponent implements OnInit {
  equipment:String;
  Price:number;
  currentFileUpload:File;
  dataone:any[];
  result:any

  constructor(private router:Router,private managerService:ManagerService) { }

  ngOnInit() {
  }
  add2(){
    this.router.navigate(["./custaddtest"]);
  }
  logout(){
    this.router.navigate(['./home']);
   
  }
  view2(){
    this.router.navigate(['./custviewtest']);
  }
  view1(){
    this.router.navigate(['./custviewequip']);
  }
  
  submit(){
    
    this.managerService.addEquipment(this.equipment,this.Price).subscribe((data:number)=>{
      this.result=data;
      if(this.result==1){
      alert("equipment added successfully")
      this.router.navigate(['./custviewequip']);
      }
      else if(this.result==2)
      alert("This Equipment added already")
      else
      alert("Enter the required fields");
    })
  }
  }
  


