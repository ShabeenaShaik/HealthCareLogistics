import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ManagerService } from './manager.service';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {

  constructor(private router:Router,private managerService:ManagerService) { }

  ngOnInit() {
  }
  view(){
    console.log(this.managerService.usermail);
    this.router.navigate(['./viewTechnicians']);
  }
  add1(){
    this.router.navigate(["./custaddequip"]);
  }
  add2(){
    this.router.navigate(["./custaddtest"]);
  }
  view2(){
    this.router.navigate(['./custviewtest']);
  }
  logout(){
    this.router.navigate(['./home']);
  }
  view1(){
    this.router.navigate(['./custviewequip']);
  }


}
