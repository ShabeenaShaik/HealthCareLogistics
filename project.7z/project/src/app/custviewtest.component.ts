import { Component, OnInit } from '@angular/core';
import { ManagerService } from './manager.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-custviewtest',
  templateUrl: './custviewtest.component.html',
  styleUrls: ['./custviewtest.component.css']
})
export class CustviewtestComponent implements OnInit {
test:any={};
  constructor(private managerService:ManagerService,private router:Router) { }

  ngOnInit() {
    this.managerService.viewTests().subscribe((data:any)=>{this.test=data});
  }
  logout(){
    this.router.navigate(['./home']);
  }
  add2(){
    this.router.navigate(["./custaddtest"]);
  }
  add1(){
    this.router.navigate(["./custaddequip"]);
  }
  view1(){
    this.router.navigate(['./custviewequip']);
  }

}
