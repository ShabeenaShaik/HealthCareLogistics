import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-manager-page',
  templateUrl: './manager-page.component.html',
  styleUrls: ['./manager-page.component.css']
})
export class ManagerPageComponent implements OnInit {

  res:boolean;
  constructor(private router:Router) { }

  ngOnInit() {
  }

  add1(){
    this.router.navigate(["./addEquipment"]);
  }
  add2(){
    this.router.navigate(["./addTests"]);
  }
  view2(){
    this.router.navigate(['./viewTests']);
  }
  logout(){
    this.router.navigate(['./home']);
  }
  view1(){
    this.router.navigate(['./viewEquipment']);
  }

}
