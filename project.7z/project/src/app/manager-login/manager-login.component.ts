import { Component, OnInit } from '@angular/core';
import { ManagerService } from '../manager.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-manager-login',
  templateUrl: './manager-login.component.html',
  styleUrls: ['./manager-login.component.css']
})
export class ManagerLoginComponent implements OnInit {

  model:any={};
  res:number;
  constructor(private managerService:ManagerService,private router:Router) { }

  ngOnInit() {
  }
  onLogin(){
    return this.managerService.validateLogin(this.model.name,this.model.password).subscribe((data:number)=>{
      this.res=data;
      console.log(this.res);
      if(this.res==1)
      this.router.navigate(['./managerPage']);
      else if(this.res==2)
      this.router.navigate(['./technicianPage'])
      else if(this.res==3)
      this.router.navigate(['./customer']);
      else
      alert("You are not registered!!!");
    })
    
  }


}
