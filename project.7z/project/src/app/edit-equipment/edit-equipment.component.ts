import { Component, OnInit } from '@angular/core';
import { ManagerService } from '../manager.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-edit-equipment',
  templateUrl: './edit-equipment.component.html',
  styleUrls: ['./edit-equipment.component.css']
})
export class EditEquipmentComponent implements OnInit {
eName:any;
ePrice:any;

  constructor(private managerService:ManagerService,private router:Router) { }
  save(eprice:any){
    this.ePrice=eprice;
    return this.managerService.saveEditedEquipment(this.eName,this.ePrice).subscribe((data:any)=>{
      if(data==1)
      alert("updated successfully");
      this.router.navigate(["./viewEquipment"]);
    });
  }
  

  ngOnInit() {
    this.eName=this.managerService.eName;
    this.ePrice=this.managerService.eprice;
  }
  logout(){
    this.router.navigate(['./home']);
  }
  view2(){
    this.router.navigate(['./viewTests']);
  }
  add1(){
    this.router.navigate(["./addEquipment"]);
  }
add2(){
  this.router.navigate(['./addTests']);
}
  view1(){
    this.router.navigate(['./viewEquipment']);
  }

}
