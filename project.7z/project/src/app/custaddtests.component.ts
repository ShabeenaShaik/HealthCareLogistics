import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ManagerService } from './manager.service';

@Component({
  selector: 'app-custaddtests',
  templateUrl: './custaddtests.component.html',
  styleUrls: ['./custaddtests.component.css']
})
export class CustaddtestsComponent implements OnInit {
  data:any={};
  res:number;
  constructor(private router:Router,private managerService:ManagerService) { }

  ngOnInit() {
  }
  submit(){
    return this.managerService.submitTest(this.data).subscribe((data1:number)=>
      {this.res=data1;
        if(this.res==1){
        alert("Test added successfully")
        this.router.navigate(['./custviewtest']);
        }
        else if(this.res==2)
        alert("This test added already");
        else
        alert("Enter the required fields");
      });
  
  }
  logout(){
    this.router.navigate(['./home']);
  }
  view2(){
    this.router.navigate(['./custviewtest']);
  }
  add1(){
    this.router.navigate(["./addEquipment"]);
  }

  view1(){
    this.router.navigate(['./custviewequip']);
  }

}
